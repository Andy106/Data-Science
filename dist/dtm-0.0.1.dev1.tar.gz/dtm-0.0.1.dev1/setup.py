from setuptools import setup

setup(name='dtm',
      packages=['dtm'],
      version='0.0.1dev1',
      )